# Symbol Overview Widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gab-Blood/pen/ByByRje](https://codepen.io/Gab-Blood/pen/ByByRje).

